﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Login2.Models;
using Login2.ViewModels;
using Microsoft.AspNetCore.Identity;

namespace Login2.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<MyIdentityUser> userManager;
        private readonly SignInManager<MyIdentityUser> loginManager;
        private readonly RoleManager<MyIdentityRole> roleManager;

        public AccountController(UserManager<MyIdentityUser> userManager,
            SignInManager<MyIdentityUser> loginManager,
            RoleManager<MyIdentityRole> roleManager)
        {
            this.userManager = userManager;
            this.loginManager = loginManager;
            this.roleManager = roleManager;

        }
        [HttpGet]
        public IActionResult Register()
        {
            return View();
        }

        /*
        [HttpPost]
        public IActionResult Register(RegisterViewModel obj)
        {
            if (ModelState.IsValid)
            {
                MyIdentityUser user = new MyIdentityUser();
                IdentityResult result = userManager.CreateAsync(user, obj.Password).Result;
                if (result.Succeeded)
                {
                    if (!roleManager.RoleExistsAsync("NormalUser").Result)
                    {
                        MyIdentityRole role = new MyIdentityRole();
                        role.Name = "NormalUser";
                        role.Description = "Perform Normal Operations.";
                        IdentityResult roleResult = roleManager.CreateAsync(role).Result;
                        if (!roleResult.Succeeded)
                        {
                            ModelState.AddModelError("", "Error while creating role!");
                            return View(obj);
                        }
                    }
                    userManager.AddToRoleAsync(user, "NormalUser").Wait();
                    return RedirectToAction("Login","Account");

                }
            }
            return View(obj);
        }
        */

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterViewModel obj)
        {
            if (ModelState.IsValid)
            {
                MyIdentityUser user = new MyIdentityUser();
                user.UserName = obj.UserName;
                user.Email = obj.UserEmail;
                user.PhoneNumber = obj.UserPhone;

                IdentityResult result = userManager.CreateAsync(user, obj.Password).Result;
                if (result.Succeeded)
                {
    
                        if (!roleManager.RoleExistsAsync("NormalUser").Result)
                        {
                            MyIdentityRole role = new MyIdentityRole();
                            role.Name = "NormalUser";
                            role.Description = "Perform Normal Operations.";
                            IdentityResult roleResult = roleManager.CreateAsync(role).Result;
                            if (!roleResult.Succeeded)
                            {
                                ModelState.AddModelError("", "Error while creating role!");
                                return View(obj);
                            }
                        }
                        userManager.AddToRoleAsync(user, "NormalUser").Wait();
                        return RedirectToAction("Login", "Account");             
                }
                else
                {
                    IEnumerable<IdentityError> errors = result.Errors;
                    foreach(var item in errors)
                    {
                        ModelState.AddModelError("", item.Description);
                    }

                }

            }
            return View(obj);
        }


       public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult Login()
        {
            return View();

        }

        [HttpPost]
        public IActionResult Login(LoginViewModel obj)
        {
            if (ModelState.IsValid)
            {
                var result = loginManager.PasswordSignInAsync(obj.UserName, obj.Password, obj.RememberMe, false).Result;

                if (result.Succeeded)
                {
                    return RedirectToAction("Index","Home");
                }
                ModelState.AddModelError("validmsg", "Invalid Login!");
            }
            return View(obj);

        }

        public IActionResult LogOff()
        {
            loginManager.SignOutAsync().Wait();
            return RedirectToAction("Login", "Account");
        }

    }
}
